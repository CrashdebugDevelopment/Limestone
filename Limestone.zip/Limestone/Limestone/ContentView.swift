//
//  ContentView.swift
//  Limestone
//
//  Created by Karl Ehrlich on 17.08.24.
//

import SwiftUI

struct NewsBlock: View {
    
    var title: String
    var description: String
    var imageName: String
    var externalLink: String
    
    var body: some View {
        HStack {
            Image(imageName)
                .resizable()
                .frame(width: 220)
            VStack(alignment: .leading) {
                Text(title)
                    .font(.title2)
                    .fontWeight(.semibold)
                Text(description)
                    .foregroundStyle(.secondary)
                    .font(.subheadline)
                Spacer(minLength: 0)
                Link(destination: URL(string: externalLink)!, label: {
                    HStack {
                        Text("Learn more")
                        Image(systemName: "chevron.right")
                            .font(.caption)
                    }
                })
            }
            .padding()
        }
    }
}

struct RecentProject: Identifiable, Codable {
    var id = UUID()
    var url: URL
    var lastModified: Date = .now
}

struct IconManager {
    static func iconForExtension(_ pathExtension: String) -> Image {
        switch pathExtension {
        case "cpp": return Image("c-plus-plus")
        case "c": return Image("c-programming")
        case "cs": return Image("c-sharp-logo")
        case "css": return Image("css3")
        case "dart": return Image("dart")
        case "docker": return Image("docker")
        case "go": return Image("golang")
        case "html": return Image("html")
        case "java": return Image("java")
        case "js": return Image("javascript")
        case "jl": return Image("julia")
        case "kt": return Image("kotlin")
        case "py": return Image("python")
        case "rb": return Image("ruby")
        case "scss": return Image("sass")
        case "swift": return Image("swift")
        case "ts": return Image("typescript")
        case "rtf": return Image(systemName: "doc.richtext")
        case "csv": return Image(systemName: "table")
        case "json": return Image(systemName: "curlybraces")
        default: return Image(systemName: "doc")
        }
    }
}

struct NewsStorage: Codable {
    var title: String
    var description: String
    var externalLink: String
    var imageName: String
}

class RecentProjectManager: ObservableObject {
    static let shared = RecentProjectManager()
    
    @Published var recentProjects: [RecentProject] = [] {
        didSet {
            saveRecentProjects()
        }
    }
    
    private let userDefaultsKey = "RecentProjects"
    private let maxRecentProjects = 6

    private init() {
        loadRecentProjects()
    }
    
    func addOrUpdateRecent(_ url: URL) {
        if let index = recentProjects.firstIndex(where: { $0.url == url }) {
            // Update the lastModified date if the project exists
            recentProjects[index].lastModified = .now
        } else {
            // Add a new project if it doesn't exist
            if recentProjects.count >= maxRecentProjects {
                // Remove the oldest project if the limit is reached
                recentProjects.sort { $0.lastModified > $1.lastModified }
                recentProjects.removeLast()
            }
            recentProjects.append(RecentProject(url: url))
        }
        
        // Ensure the list is sorted with the newest project first
        recentProjects.sort { $0.lastModified > $1.lastModified }
    }
    
    func removeRecent(_ url: URL) {
        recentProjects.removeAll { $0.url == url }
        saveRecentProjects()
    }
    
    private func saveRecentProjects() {
        do {
            let data = try JSONEncoder().encode(recentProjects)
            UserDefaults.standard.set(data, forKey: userDefaultsKey)
        } catch {
            print("Failed to save recent projects: \(error)")
        }
    }
    
    private func loadRecentProjects() {
        if let data = UserDefaults.standard.data(forKey: userDefaultsKey) {
            do {
                recentProjects = try JSONDecoder().decode([RecentProject].self, from: data)
                // Ensure the list is sorted with the newest project first on load
                recentProjects.sort { $0.lastModified > $1.lastModified }
            } catch {
                print("Failed to load recent projects: \(error)")
            }
        }
    }
}

struct ContentView: View {
    
    @State private var showFolderPicker = false
    @State private var showFilePicker = false
    @State private var showFileExporter = false
    
    let circulateNews = Timer.publish(every: 8, on: .current, in: .common) .autoconnect()
    @State private var newsSelection = 0
    
    @Environment(\.openWindow) var openWindow
    
    var body: some View {
        NavigationSplitView {
            List {
                Button {
                    showFileExporter.toggle()
                } label: {
                    Label("Create", systemImage: "plus.square.fill")
                }
                Button {
                    showFilePicker.toggle()
                } label: {
                    Label("Open script", systemImage: "square.and.arrow.down")
                }
                .fileImporter(isPresented: $showFilePicker, allowedContentTypes: [.text, .plainText]) { result in
                    if let result = try? result.get() {
                        RecentProjectManager.shared.addOrUpdateRecent(result)
                        openWindow(id: "editor", value: result)
                    }
                }
                Button("TEST") {
                    let json = """
{
    "title": "Foobar",
    "description": "Deserunt mollit aliquip eu ex tempor Lorem sint tempor irure enim aliquip ea fugiat consequat. Est irure aute est. Ullamco voluptate nisi sunt laborum nulla non non occaecat elit. Consequat exercitation cupidatat Lorem sit quis consequat id exercitation excepteur eu minim cupidatat dolore pariatur proident. Laboris cillum adipisicing aliqua magna eiusmod dolore non magna.",
    "imageName": "logo_baz",
    "externalLink": "https://foobar.baz"
    
}
"""
                    let decoder = JSONDecoder()
                    if let newsBlock = try? decoder.decode(NewsStorage.self, from: json.data(using: .utf8) ?? Data()) {
                        print(newsBlock)
                    }
                }
                Button {
                    showFolderPicker.toggle()
                } label: {
                    Label("Open directory", systemImage: "folder")
                }
                .fileImporter(isPresented: $showFolderPicker, allowedContentTypes: [.folder]) { result in
                    //RecentProjectManager.shared.addOrUpdateRecent(result)
                }
                Section("Recent") {
                    ForEach(RecentProjectManager.shared.recentProjects.prefix(3)) { project in
                        HStack {
                            IconManager.iconForExtension(project.url.pathExtension)
                                .frame(width: 25)
                            Text(project.url.lastPathComponent)
                                .lineLimit(1)
                            Spacer(minLength: 0)
                        }
                        .contextMenu {
                            Button(role: .destructive) {
                                RecentProjectManager.shared.removeRecent(project.url)
                            } label: {
                                Label("Remove", systemImage: "trash")
                            }
                        }
                    }
                }
                Section("Favourites") {
                    Label("2023", systemImage: "folder")
                    Label("2024", systemImage: "folder")
                    Button {
                        
                    } label: {
                        Label("Add", systemImage: "plus")
                    }
                }
            }
            .navigationTitle("Limestone")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        
                    } label: {
                        Image(systemName: "gear")
                    }
                }
            }
        } detail: {
            List {
                TabView(selection: $newsSelection) {
                    NewsBlock(title: "Try CodeEdit© for macOS", description: "CodeEdit is a powerful open-source code editor designed for developers who value efficiency and customization. Built for macOS, it offers features like syntax highlighting, project management, and Git integration. With an active community driving its evolution, CodeEdit delivers a seamless and intuitive experience, making it an ideal choice for developers seeking a reliable and flexible coding environment.", imageName: "logo_codeedit", externalLink: "https://codeedit.app") .tag(0)
                    NewsBlock(title: "Introducing Limestone", description: "CodeEdit is a powerful open-source code editor designed for developers who value efficiency and customization. Built for macOS, it offers features like syntax highlighting, project management, and Git integration. With an active community driving its evolution, CodeEdit delivers a seamless and intuitive experience, making it an ideal choice for developers seeking a reliable and flexible coding environment.", imageName: "logo_app", externalLink: "https://codeedit.app") .tag(1)
                }
                .frame(height: 220)
                .listRowInsets(EdgeInsets())
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
                .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
                
                Section {
                    ForEach(RecentProjectManager.shared.recentProjects) { project in
                        HStack {
                            IconManager.iconForExtension(project.url.pathExtension)
                                .frame(width: 25)
                            Text(project.url.lastPathComponent)
                                .lineLimit(1)
                            Spacer()
                            Text(project.lastModified.formatted(date: .abbreviated, time: .shortened))
                                .lineLimit(1)
                                .foregroundStyle(.secondary)
                        }
                        .contextMenu {
                            Button(role: .destructive) {
                                RecentProjectManager.shared.removeRecent(project.url)
                            } label: {
                                Label("Remove", systemImage: "trash")
                            }
                        }
                    }
                } header: {
                    HStack {
                        Text("Recents")
                        Spacer()
                        Text("Last edited")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
                .headerProminence(.increased)
            }
            .navigationTitle("What's new")
            .listSectionSeparator(.hidden)
        }
        .onReceive(circulateNews) { _ in
            withAnimation {
                if newsSelection == 0 {
                    newsSelection = 1
                } else {
                    newsSelection = 0
                }
            }
        }
    }
}


#Preview {
    ContentView()
}
