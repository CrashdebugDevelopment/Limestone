//
//  LimestoneApp.swift
//  Limestone
//
//  Created by Karl Ehrlich on 17.08.24.
//

import SwiftUI

@main
struct LimestoneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
